import { createFileRoute } from "@tanstack/react-router";

import { Nav } from "@/components/polen/Nav";
import { Hero } from "@/components/polen/Hero";
import { CaosOrden } from "@/components/polen/CaosOrden";
import { Servicios } from "@/components/polen/Servicios";
import { Diferencial } from "@/components/polen/Diferencial";
import { Contacto } from "@/components/polen/Contacto";
import { Footer } from "@/components/polen/Footer";
import { WhatsappFab } from "@/components/polen/WhatsappFab";
import { useSmoothAnchors } from "@/components/polen/useSmoothAnchors";

const TITLE = "POLEN | Agencia digital integral: producto, UX/UI e IA";
const DESCRIPTION =
  "Discovery estratégico, diseño UX/UI, desarrollo de software a medida y consultoría en inteligencia artificial aplicada a procesos de negocio.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  useSmoothAnchors();

  return (
    <div className="min-h-screen overflow-x-hidden bg-background">
      <Nav />
      <main>
        <Hero />
        <CaosOrden />
        <Servicios />
        <Diferencial />
        <Contacto />
      </main>
      <Footer />
      <WhatsappFab />
    </div>
  );
}

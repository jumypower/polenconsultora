import { motion } from "motion/react";

import caosImage from "@/assets/caos.jpg";
import ordenImage from "@/assets/orden.jpg";

const CAOS = [
  "Se pide 'una app' sin haber definido el problema de negocio",
  "Procesos manuales y datos dispersos en planillas sueltas",
  "Interfaces heredadas que nadie quiere usar",
  "Pilotos de IA que nunca llegan a producción",
];

const ORDEN = [
  "Discovery con KPIs claros y oportunidades priorizadas",
  "Arquitectura de datos ordenada y lista para escalar",
  "Diseño UX/UI validado con usuarios reales antes de construir",
  "Modelos e integraciones funcionando dentro del proceso diario",
];

export function CaosOrden() {
  return (
    <section id="caos" className="mx-auto max-w-6xl px-5 py-24 sm:py-32">
      <motion.h2
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
          className="max-w-3xl text-3xl font-black leading-tight sm:text-5xl"
        >
          De ejecutar pedidos a construir productos que mueven el negocio
      </motion.h2>

      <div className="mt-14 grid gap-6 md:grid-cols-2">
        {[
          { img: caosImage, alt: "Equipo de trabajo desbordado por procesos manuales", title: "Software factory tradicional", items: CAOS, tone: "caos" },
          { img: ordenImage, alt: "Equipo trabajando con un producto digital ordenado", title: "Socio estratégico de producto", items: ORDEN, tone: "orden" },
        ].map((block, index) => (
          <motion.article
            key={block.title}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, delay: index * 0.12 }}
            className={
              block.tone === "orden"
                ? "overflow-hidden rounded-3xl bg-primary/15 shadow-soft"
                : "overflow-hidden rounded-3xl bg-card shadow-soft"
            }
          >
            <img
              src={block.img}
              alt={block.alt}
              loading="lazy"
              width={1200}
              height={1200}
              className={
                block.tone === "caos"
                  ? "h-56 w-full object-cover grayscale sm:h-64"
                  : "h-56 w-full object-cover sm:h-64"
              }
            />
            <div className="p-7">
              <h3 className="text-xl font-black">{block.title}</h3>
              <ul className="mt-5 space-y-3 text-sm leading-relaxed text-muted-foreground">
                {block.items.map((item) => (
                  <li key={item} className="flex gap-3">
                    <span
                      className={
                        block.tone === "orden"
                          ? "mt-2 size-1.5 shrink-0 rounded-full bg-ink"
                          : "mt-2 size-1.5 shrink-0 rounded-full bg-muted-foreground/50"
                      }
                    />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
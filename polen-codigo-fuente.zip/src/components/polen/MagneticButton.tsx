import { useRef, useState, type ReactNode } from "react";
import { motion, useReducedMotion } from "motion/react";

import { cn } from "@/lib/utils";

type Props = {
  href: string;
  children: ReactNode;
  className?: string;
  variant?: "solid" | "outline";
  target?: string;
  rel?: string;
};

export function MagneticButton({
  href,
  children,
  className,
  variant = "solid",
  target,
  rel,
}: Props) {
  const ref = useRef<HTMLAnchorElement>(null);
  const reduce = useReducedMotion();
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  return (
    <motion.a
      ref={ref}
      href={href}
      target={target}
      rel={rel}
      onPointerMove={(event) => {
        if (reduce || event.pointerType !== "mouse") return;
        const rect = ref.current?.getBoundingClientRect();
        if (!rect) return;
        setOffset({
          x: (event.clientX - (rect.left + rect.width / 2)) * 0.25,
          y: (event.clientY - (rect.top + rect.height / 2)) * 0.35,
        });
      }}
      onPointerLeave={() => setOffset({ x: 0, y: 0 })}
      animate={{ x: offset.x, y: offset.y }}
      transition={{ type: "spring", stiffness: 260, damping: 18 }}
      whileTap={{ scale: 0.96 }}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full px-7 py-4 text-sm font-bold tracking-tight transition-colors",
        variant === "solid"
          ? "bg-primary text-primary-foreground shadow-soft hover:bg-primary/90"
          : "border border-ink/20 text-foreground hover:border-ink/50",
        className,
      )}
    >
      {children}
    </motion.a>
  );
}
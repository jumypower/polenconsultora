import { useState } from "react";
import { motion } from "motion/react";
import { z } from "zod";

import { EMAIL, whatsappLink } from "./constants";

const schema = z.object({
  nombre: z.string().trim().min(2, "Contanos tu nombre").max(80, "Máximo 80 caracteres"),
  negocio: z.string().trim().min(2, "¿Cómo se llama tu negocio?").max(80, "Máximo 80 caracteres"),
  rubro: z.string().trim().min(2, "Contanos tu rubro").max(60, "Máximo 60 caracteres"),
  email: z.string().trim().min(1, "Dejanos un mail").email("Mail inválido").max(120, "Máximo 120 caracteres"),
  telefono: z
    .string()
    .trim()
    .min(6, "Dejanos un teléfono")
    .max(30, "Máximo 30 caracteres")
    .regex(/^[0-9+()\s-]+$/, "Solo números, espacios y +"),
  mensaje: z.string().trim().min(10, "Contanos un poco más").max(600, "Máximo 600 caracteres"),
});

type Errors = Partial<Record<keyof z.infer<typeof schema>, string>>;

const FIELDS = [
  { name: "nombre", label: "Tu nombre", placeholder: "Ana Pérez", type: "text", full: false },
  { name: "negocio", label: "Empresa", placeholder: "Nombre de tu empresa", type: "text", full: false },
  { name: "email", label: "Mail", placeholder: "ana@empresa.com", type: "email", full: false },
  { name: "telefono", label: "Teléfono", placeholder: "+54 9 294 ...", type: "tel", full: false },
  { name: "rubro", label: "Industria", placeholder: "Retail, salud, logística, fintech...", type: "text", full: true },
] as const;

export function Contacto() {
  const [values, setValues] = useState({
    nombre: "",
    negocio: "",
    rubro: "",
    email: "",
    telefono: "",
    mensaje: "",
  });
  const [errors, setErrors] = useState<Errors>({});

  const buildMessage = (data: z.infer<typeof schema>) =>
    `Hola POLEN, soy ${data.nombre} de ${data.negocio} (${data.rubro}).\n\nMail: ${data.email}\nTel: ${data.telefono}\n\n${data.mensaje}`;

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const result = schema.safeParse(values);
    if (!result.success) {
      const next: Errors = {};
      for (const issue of result.error.issues) {
        next[issue.path[0] as keyof Errors] = issue.message;
      }
      setErrors(next);
      return;
    }
    setErrors({});
    window.open(whatsappLink(buildMessage(result.data)), "_blank", "noopener");
  };

  return (
    <section id="contacto" className="mx-auto max-w-4xl px-5 py-24 sm:py-32">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        className="rounded-[2rem] bg-card p-7 shadow-lift sm:p-12"
      >
        <h2 className="text-3xl font-black leading-tight sm:text-4xl">
          Empecemos por el análisis previo,
          <br />
          no por la herramienta
        </h2>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">
          Contanos qué producto o proceso querés transformar. Volvemos con un mapa inicial de
          oportunidades y el enfoque técnico que recomendamos, sin compromiso.
        </p>

        <form onSubmit={handleSubmit} noValidate className="mt-9 space-y-5">
          <div className="grid gap-5 sm:grid-cols-2">
            {FIELDS.map((field) => (
              <div key={field.name} className={field.full ? "sm:col-span-2" : undefined}>
                <label htmlFor={field.name} className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  {field.label}
                </label>
                <input
                  id={field.name}
                  name={field.name}
                  type={field.type}
                  value={values[field.name]}
                  maxLength={120}
                  onChange={(event) =>
                    setValues((prev) => ({ ...prev, [field.name]: event.target.value }))
                  }
                  placeholder={field.placeholder}
                  className="mt-2 w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
                />
                {errors[field.name] ? (
                  <p className="mt-1.5 text-xs font-medium text-destructive">{errors[field.name]}</p>
                ) : null}
              </div>
            ))}
          </div>

          <div>
            <label htmlFor="mensaje" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              ¿Qué te está costando más?
            </label>
            <textarea
              id="mensaje"
              name="mensaje"
              rows={4}
              maxLength={600}
              value={values.mensaje}
              onChange={(event) => setValues((prev) => ({ ...prev, mensaje: event.target.value }))}
              placeholder="Queremos rediseñar nuestra plataforma e integrar IA en la atención..."
              className="mt-2 w-full resize-none rounded-2xl border border-border bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
            />
            {errors.mensaje ? (
              <p className="mt-1.5 text-xs font-medium text-destructive">{errors.mensaje}</p>
            ) : null}
          </div>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <motion.button
              type="submit"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              className="rounded-full bg-primary px-8 py-4 text-sm font-bold text-primary-foreground shadow-soft"
            >
              Enviar por WhatsApp
            </motion.button>
            <a
              href={`mailto:${EMAIL}`}
              className="text-sm font-bold text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
            >
              o escribinos a {EMAIL}
            </a>
          </div>
        </form>
      </motion.div>
    </section>
  );
}

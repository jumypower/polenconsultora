import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";

import bgImage from "@/assets/patagonia.jpg";

const PILARES = [
  {
    title: "End-to-end",
    text: "Discovery, diseño, ingeniería e IA en un mismo equipo: sin traspasos que diluyan la estrategia entre proveedores.",
  },
  {
    title: "AI-mindset",
    text: "La inteligencia artificial no se agrega al final: atraviesa el análisis, el diseño de la experiencia y la arquitectura desde el día uno.",
  },
  {
    title: "Análisis antes que herramienta",
    text: "Primero entendemos dónde se pierde tiempo y margen. Recién después elegimos tecnología. Nunca al revés.",
  },
];

export function Diferencial() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["-12%", "12%"]);
  const wordY = useTransform(scrollYProgress, [0, 1], ["30%", "-30%"]);

  return (
    <section id="diferencial" ref={ref} className="relative isolate overflow-hidden py-28 sm:py-36">
      <motion.img
        src={bgImage}
        alt=""
        aria-hidden="true"
        loading="lazy"
        width={1920}
        height={1080}
        style={{ y: bgY }}
        className="absolute inset-0 -z-20 size-full scale-125 object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-ink/85" />

      <motion.span
        style={{ y: wordY }}
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-1/2 -z-10 text-center font-display text-[22vw] font-black leading-none text-ink-foreground/5"
      >
        PRODUCTO
      </motion.span>

      <div className="mx-auto max-w-6xl px-5 text-ink-foreground">
        <motion.h2
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          className="max-w-3xl text-3xl font-black leading-tight sm:text-5xl"
        >
          Un socio estratégico de producto, no una fábrica de software
        </motion.h2>

        <div className="mt-14 grid gap-10 sm:grid-cols-3">
          {PILARES.map((pilar, index) => (
            <motion.div
              key={pilar.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <span className="block h-1 w-12 rounded-full bg-primary" />
              <h3 className="mt-5 text-lg font-black">{pilar.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-ink-foreground/75">{pilar.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
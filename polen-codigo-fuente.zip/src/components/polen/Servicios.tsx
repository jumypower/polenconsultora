import { motion } from "motion/react";
import { Compass, LayoutDashboard, Code2, BrainCircuit } from "lucide-react";

const SERVICIOS = [
  {
    icon: Compass,
    title: "Análisis previo y discovery",
    resumen: "Diagnóstico del negocio antes de escribir la primera línea de código.",
    detalle:
      "Investigación de usuarios, análisis heurístico, definición de KPIs y mapa de oportunidades. Identificamos los puntos de fricción operativos que conviene optimizar con tecnología e IA, y los priorizamos por impacto.",
  },
  {
    icon: LayoutDashboard,
    title: "Diseño UX/UI y product design",
    resumen: "Interfaces intuitivas y design systems pensados para convertir.",
    detalle:
      "Arquitectura de la información, prototipado interactivo y testeos de usabilidad para web y mobile. Diseñamos también la interacción humano-IA: conversational UX y copilotos que la gente realmente entiende y usa.",
  },
  {
    icon: Code2,
    title: "Desarrollo a medida",
    resumen: "Ingeniería robusta, escalable y segura, de punta a punta.",
    detalle:
      "Frontend, backend, APIs e integración cloud con buenas prácticas de ingeniería. Modernizamos plataformas legacy e integramos microservicios con entrega continua, sin frenar la operación en marcha.",
  },
  {
    icon: BrainCircuit,
    title: "Consultoría e integración de IA",
    resumen: "IA generativa y automatización dentro de tus procesos reales.",
    detalle:
      "Implementación de modelos LLM, analítica predictiva, automatización inteligente (RPA + IA) y agentes autónomos. Sumamos estrategia de datos, gobernanza y arquitectura para una adopción segura.",
  },
];

export function Servicios() {
  return (
    <section id="servicios" className="bg-ink py-24 text-ink-foreground sm:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <motion.h2
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          className="max-w-3xl text-3xl font-black leading-tight sm:text-5xl"
        >
          Un servicio integral: del discovery al producto en producción
        </motion.h2>

        <div className="mt-14 grid gap-5 sm:grid-cols-2">
          {SERVICIOS.map((servicio, index) => (
            <motion.article
              key={servicio.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              whileHover={{ y: -10 }}
              className="group relative overflow-hidden rounded-3xl border border-ink-foreground/10 bg-ink-foreground/5 p-8 transition-colors hover:border-primary/60"
            >
              <servicio.icon className="size-9 text-primary" />
              <h3 className="mt-6 text-xl font-black">{servicio.title}</h3>
              <p className="mt-2 text-sm text-ink-foreground/70">{servicio.resumen}</p>
              <p className="mt-4 max-h-0 overflow-hidden text-sm leading-relaxed text-ink-foreground/80 opacity-0 transition-all duration-500 group-hover:max-h-44 group-hover:opacity-100 group-focus-within:max-h-44 group-focus-within:opacity-100">
                {servicio.detalle}
              </p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
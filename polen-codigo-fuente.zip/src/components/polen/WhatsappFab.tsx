import { motion } from "motion/react";
import { MessageCircle } from "lucide-react";

import { whatsappLink } from "./constants";

export function WhatsappFab() {
  return (
    <motion.a
      href={whatsappLink("Hola POLEN, quiero ordenar la operación de mi negocio en Bariloche.")}
      target="_blank"
      rel="noreferrer"
      aria-label="Escribinos por WhatsApp"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 0.8, type: "spring", stiffness: 200, damping: 16 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.94 }}
      className="fixed bottom-5 right-5 z-50 grid size-14 place-items-center rounded-full bg-ink text-ink-foreground shadow-lift"
    >
      <MessageCircle className="size-6" />
    </motion.a>
  );
}
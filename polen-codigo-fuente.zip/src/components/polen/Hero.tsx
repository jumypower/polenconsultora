import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";

import heroImage from "@/assets/patagonia.jpg";
import { MagneticButton } from "./MagneticButton";
import { whatsappLink } from "./constants";

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "28%"]);
  const titleY = useTransform(scrollYProgress, [0, 1], ["0%", "-40%"]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section id="top" ref={ref} className="relative isolate overflow-hidden">
      <motion.img
        src={heroImage}
        alt="Cordillera y lagos de Bariloche al amanecer"
        width={1920}
        height={1080}
        style={{ y: bgY }}
        className="absolute inset-0 -z-20 size-full scale-110 object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-background/80 backdrop-blur-[2px]" />
      <div className="absolute -right-24 top-24 -z-10 size-72 rounded-full bg-primary/40 blur-3xl sm:size-96" />

      <motion.div
        style={{ y: titleY, opacity: fade }}
        className="mx-auto flex min-h-[100svh] max-w-5xl flex-col justify-center px-5 pb-20 pt-32"
      >
        <motion.span
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="w-fit rounded-full border border-ink/15 bg-background/70 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.18em] text-muted-foreground"
        >
          Agencia digital integral · Diseño, producto e IA
        </motion.span>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.6 }}
          className="mt-6 text-[2.4rem] font-black leading-[1.08] sm:text-6xl lg:text-7xl"
        >
          Productos digitales que nacen{" "}
          <span className="box-decoration-clone bg-primary px-2 py-0.5 leading-[1.2]">
            de una estrategia,
            <br />
            no de un pedido
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.6 }}
          className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg"
        >
          Discovery estratégico, diseño UX/UI, desarrollo a medida y consultoría en inteligencia
          artificial aplicada: un solo equipo de punta a punta, con AI-mindset.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.6 }}
          className="mt-9 flex flex-wrap items-center gap-3"
        >
          <MagneticButton
            href={whatsappLink("Hola POLEN, quiero agendar un análisis previo.")}
            target="_blank"
            rel="noreferrer"
          >
            Polinizamos tus ideas
          </MagneticButton>
          <a
            href="#servicios"
            className="text-sm font-bold text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
          >
            Ver servicios
          </a>
        </motion.div>
      </motion.div>
    </section>
  );
}
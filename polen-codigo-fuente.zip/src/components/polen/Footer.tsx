import { EMAIL, WHATSAPP_DISPLAY, whatsappLink } from "./constants";
import polenLogo from "@/assets/polen-logo.png.asset.json";

export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto grid max-w-6xl gap-6 px-5 py-12 sm:flex sm:items-center sm:justify-between">
        <div className="flex min-w-0 items-center gap-3">
          <img src={polenLogo.url} alt="POLEN" className="h-9 w-auto" />
          <span className="truncate text-sm text-muted-foreground">· Bariloche, Patagonia</span>
        </div>
        <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
          <a
            href={whatsappLink("Hola POLEN!")}
            target="_blank"
            rel="noreferrer"
            className="hover:text-foreground"
          >
            {WHATSAPP_DISPLAY}
          </a>
          <a href={`mailto:${EMAIL}`} className="hover:text-foreground">
            {EMAIL}
          </a>
        </div>
      </div>
    </footer>
  );
}
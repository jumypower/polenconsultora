export const WHATSAPP_NUMBER = "5492944999091";
export const WHATSAPP_DISPLAY = "+54 9 2944 99-9091";
export const EMAIL = "hola@polen.ai";

export function whatsappLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}